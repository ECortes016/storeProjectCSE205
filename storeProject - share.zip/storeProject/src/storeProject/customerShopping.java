package storeProject;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SpinnerNumberModel;

public class customerShopping {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					customerShopping window = new customerShopping();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public customerShopping() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 600, 420);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel shoppingCartText = new JLabel("Shopping Cart");
		shoppingCartText.setFont(new Font("Nunito", Font.PLAIN, 16));
		shoppingCartText.setBounds(20, 22, 165, 28);
		frame.getContentPane().add(shoppingCartText);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(20, 50, 200, 190);
		frame.getContentPane().add(panel);
		
		JComboBox itemList = new JComboBox();
		itemList.setToolTipText("Select Item");
		itemList.setBounds(270, 50, 165, 22);
		frame.getContentPane().add(itemList);
		itemList.addItem("Apple");
		itemList.addItem("Pear");
		itemList.addItem(null);
		
		JLabel availability = new JLabel("In stock: -1");
		availability.setFont(new Font("Nunito", Font.PLAIN, 14));
		availability.setBounds(270, 83, 140, 22);
		frame.getContentPane().add(availability);
		
		JSpinner spinner = new JSpinner();
		spinner.setModel(new SpinnerNumberModel(0, null, 3, 1));
		spinner.setBounds(405, 117, 30, 20);
		frame.getContentPane().add(spinner);
		
		JLabel amtSelected = new JLabel("Amount selected -");
		amtSelected.setFont(new Font("Nunito", Font.PLAIN, 14));
		amtSelected.setBounds(270, 116, 116, 20);
		frame.getContentPane().add(amtSelected);
		
		JButton addBtn = new JButton("Add to cart");
		addBtn.setBounds(294, 198, 116, 23);
		frame.getContentPane().add(addBtn);
		
		JButton logoutBtn = new JButton("Logout");
		logoutBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		logoutBtn.setBounds(20, 331, 89, 23);
		frame.getContentPane().add(logoutBtn);
		
		JButton orderBtn = new JButton("Place Order");
		orderBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		orderBtn.setBounds(20, 251, 89, 23);
		frame.getContentPane().add(orderBtn);
		
		JButton cartModify = new JButton("Modify Cart");
		cartModify.setBounds(119, 251, 89, 23);
		frame.getContentPane().add(cartModify);
	}
}
