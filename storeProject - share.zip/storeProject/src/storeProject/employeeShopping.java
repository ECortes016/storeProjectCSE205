package storeProject;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SpinnerNumberModel;
import javax.swing.JTextField;

public class employeeShopping {

	private JFrame frame;
	private JTextField textField_1;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					employeeShopping window = new employeeShopping();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public employeeShopping() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 600, 420);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel shoppingCartText = new JLabel("Shopping Cart");
		shoppingCartText.setFont(new Font("Nunito", Font.PLAIN, 16));
		shoppingCartText.setBounds(20, 22, 165, 28);
		frame.getContentPane().add(shoppingCartText);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(20, 50, 200, 190);
		frame.getContentPane().add(panel);
		
		JComboBox itemList = new JComboBox();
		itemList.setToolTipText("Select Item");
		itemList.setBounds(270, 50, 165, 22);
		frame.getContentPane().add(itemList);
		itemList.addItem("Apple");
		itemList.addItem("Pear");
		itemList.addItem(null);
		
		JLabel availability = new JLabel("In stock: -1");
		availability.setFont(new Font("Nunito", Font.PLAIN, 14));
		availability.setBounds(270, 83, 140, 22);
		frame.getContentPane().add(availability);
		
		JSpinner spinner = new JSpinner();
		spinner.setModel(new SpinnerNumberModel(0, null, 3, 1));
		spinner.setBounds(405, 117, 30, 20);
		frame.getContentPane().add(spinner);
		
		JLabel amtSelected = new JLabel("Amount selected -");
		amtSelected.setFont(new Font("Nunito", Font.PLAIN, 14));
		amtSelected.setBounds(270, 116, 116, 20);
		frame.getContentPane().add(amtSelected);
		
		JButton addBtn = new JButton("Add to cart");
		addBtn.setBounds(294, 198, 116, 23);
		frame.getContentPane().add(addBtn);
		
		JButton logoutBtn = new JButton("Logout");
		logoutBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		logoutBtn.setBounds(20, 331, 89, 23);
		frame.getContentPane().add(logoutBtn);
		
		JButton orderBtn = new JButton("Place Order");
		orderBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		orderBtn.setBounds(20, 251, 89, 23);
		frame.getContentPane().add(orderBtn);
		
		JButton cartModify = new JButton("Modify Cart");
		cartModify.setBounds(119, 251, 89, 23);
		frame.getContentPane().add(cartModify);
		
		JButton pendingBtn = new JButton("Pending Orders");
		pendingBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		pendingBtn.setBounds(131, 331, 107, 23);
		frame.getContentPane().add(pendingBtn);
		
		JButton editBtn = new JButton("Edit Item");
		editBtn.setBounds(248, 331, 89, 23);
		frame.getContentPane().add(editBtn);
		
		JButton addCustomerBtn = new JButton("Add Customer");
		addCustomerBtn.setBounds(347, 331, 107, 23);
		frame.getContentPane().add(addCustomerBtn);
		
		JButton btnNewButton = new JButton("New Item");
		btnNewButton.setBounds(482, 123, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		textField_1 = new JTextField();
		textField_1.setBounds(485, 28, 86, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Item Name");
		lblNewLabel.setBounds(485, 11, 78, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Item Price");
		lblNewLabel_1.setBounds(485, 54, 78, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(485, 67, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Item Stock");
		lblNewLabel_2.setBounds(485, 98, 78, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JSpinner spinner_1 = new JSpinner();
		spinner_1.setBounds(544, 95, 30, 20);
		frame.getContentPane().add(spinner_1);
	}
}
