package storeProject;

import java.awt.EventQueue;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class startupGUI {

	private JFrame frame;
	private JTextField username;
	private JPasswordField pass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					startupGUI window = new startupGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public startupGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	void initialize() {
		frame = new JFrame("Welcome");
		frame.setBounds(100, 100, 400, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome");
		lblNewLabel.setFont(new Font("Nunito", Font.PLAIN, 24));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 11, 364, 34);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Nunito", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(138, 56, 110, 31);
		frame.getContentPane().add(lblNewLabel_1);
		
		username = new JTextField();
		username.setBounds(100, 98, 200, 20);
		frame.getContentPane().add(username);
		username.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Nunito", Font.PLAIN, 16));
		lblNewLabel_2.setBounds(138, 127, 110, 31);
		frame.getContentPane().add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("Login");
		
		btnNewButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				String jdbcURL = "jdbc:postgresql://localhost:5432/cse-final";
				String admin = "postgres";
				String password = "lily26";
				
				try {
					Connection connection = DriverManager.getConnection(jdbcURL, admin, password);
//					System.out.println("Connected successfully!");
					
					Statement stmt = connection.createStatement();
					String userPass = String.valueOf(pass.getPassword());
					
					String sql = "Select * from people where username='" + username.getText() + "' and pass='" + userPass + "'";
					ResultSet rs = stmt.executeQuery(sql);
					
					if (rs.next()) {
						JOptionPane.showMessageDialog(null, "Login Successfully");
					} else {
						JOptionPane.showMessageDialog(null, "Invalid Credentials!");
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					System.out.println("Error in connecting!");
					e1.printStackTrace();
				}
				
			}
		});
		
		btnNewButton.setBounds(159, 234, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Sign Up");
		
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				signupGUI p2 = new signupGUI();
			}
		});
		btnNewButton_1.setBounds(159, 268, 89, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		pass = new JPasswordField();
		pass.setBounds(100, 167, 200, 20);
		frame.getContentPane().add(pass);
		
		frame.setVisible(true);
	}
}
